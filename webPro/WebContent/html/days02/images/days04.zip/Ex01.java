package days04;

import java.sql.Connection;

import com.util.DBConn;

public class Ex01 {

	public static void main(String[] args) {
		// 1. DB 연동 : connection 객체 
		Connection connection = DBConn.getConnection();
		IMyBoardDAO boardDao = 
				                             new MyBoardDAOImpl(connection);		
		MyBoardService boardService = 
				new MyBoardService(boardDao);		
		MyBoardController controller =
				new MyBoardController(boardService);
		
		controller.start();


	} // main

}  // class



/* sequence diagram ( UML )
Ex01        MyBoardController              MyBoardService                                                 MyBoardDAOImpl                                  Oracle  서버              
main() 
             ->  start()
                   조/추/삭/수 메뉴출력
                                     메뉴선택(조)  ->1. ArrayList<MyBoardDTO>  게시글목록조회()       ->ArrayList<MyBoardDTO>  select()
                                     메뉴처리               2. 로그기록()                                                          LogDAO insert()
                                                           3. A()
                                                           4. B()
                 
                   게시글목록조회출력()         <-
                   ------
                   ------
*/




// 예나()
// 지현( 아파서 결석 )
// 승연( 1시간 지각 예정)








