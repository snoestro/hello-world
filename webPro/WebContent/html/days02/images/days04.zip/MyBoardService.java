package days04;

import java.sql.SQLException;
import java.util.ArrayList;

public class MyBoardService {
	private IMyBoardDAO boardDao = null;

	public MyBoardService(IMyBoardDAO boardDao) {
		this.boardDao = boardDao;
	}

	public ArrayList<MyBoardDTO> selectService() {
		ArrayList<MyBoardDTO> list = null;
		try {
			list = this.boardDao.select(1, 15);
			// 로그 기록 : logDao.loginsert()
		} catch (SQLException e) { 
			e.printStackTrace();
		}
		return list;
	}

}










