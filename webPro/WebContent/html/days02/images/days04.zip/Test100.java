package days04;

import java.util.ArrayList;

import days02.DeptDTO;

public class Test100 {
	
	public static void main(String[] args) {
		 
	}
	
/* 페이징 블럭 start/end
	public static void main(String[] args) {
		int currentPage = 1;		// 현재 페이지 번호
		int numberOfpageBlocks = 10; 		// 페이징 블럭수   1 2 3 4 5 6 7 8 9 10
		int postingsPerPage = 15; // 페이지당 게시글 수 number of posts
		int totalNumberOfPostings = 571;		// 총 게시글 수
		int numberOfPages = 
			(int) Math.ceil( ((double)totalNumberOfPostings / postingsPerPage) );
		
		1페이지   1~10
		10페이지 1~10
		11페이지 11~20
		21페이지 21~30
		30페이지 21~30
		31페이지 31~40
		
		numberOfPages = 35;
		int pageBlockStart ;
		int pageBlockEnd   ;
		for (int i = 1; i <= 31; i++) {
			pageBlockStart = ( i - 1) / numberOfpageBlocks * numberOfpageBlocks + 1;
			pageBlockEnd = pageBlockStart + numberOfpageBlocks - 1;
			pageBlockEnd = pageBlockEnd > numberOfPages ? numberOfPages : pageBlockEnd; 
			System.out.printf("%d페이지 : %d - %d\n"
					, i, pageBlockStart, pageBlockEnd);
		}
	}
*/
}










