package days04;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.util.DBConn;

public class MyBoardController {
	
	private int selectedNumber;
	private Scanner scanner  = null;
	private MyBoardService boardService = null;
	
	public  MyBoardController() {
		this.scanner = new Scanner(System.in);
	}

	public MyBoardController(MyBoardService boardService) {
		this();
		this.boardService = boardService;
	}

	public void start() {
		while(true) {
			printMenu();
			selectMenu();
			processMenu();
		}
	}

	private void processMenu() {
		switch (this.selectedNumber) {
		case 1: // 새글
			새글쓰기();
			break;
		case 2: // 목록
			게시글목록조회();
			break;
		case 3: // 보기
			break;
		case 4: // 수정
			break;
		case 5: // 삭제
			break;
		case 6: // 검색
			break;
		case 7: // 종료
			exit();
            break;
		} // swith
		
	}

	private void 새글쓰기() {
		// TODO Auto-generated method stub
		
	}

	private void 게시글목록조회() {
		// 컨트롤러 :  ArrayList<DTO>  MyBoardService.게시글목록조회()
		ArrayList<MyBoardDTO> list =
				this.boardService.selectService();		
		// 목록출력(View 역활)
		System.out.println("\t\t\t\t\t My게시판");
		System.out.println("------------------------------------------------------------");
		System.out.printf(
				"%s\t%s\t%s\t%s\t%s\n"
				,"글번호","글제목","글쓴이","작성일","조회수");
		System.out.println("------------------------------------------------------------");
		Iterator<MyBoardDTO> ir = list.iterator();
		while (ir.hasNext()) {
			MyBoardDTO dto = ir.next();
			System.out.printf(
					"%d\t%s\t%s\t%tF\t%d\n"
					, dto.getSeq(), dto.getSubject(),dto.getName()
					, dto.getRegdate(), dto.getCnt());			
		}
		System.out.println("------------------------------------------------------------");
		System.out.println("\t\t [1] 2 3 4 5 6 7 8 9 10 ▶");
		System.out.println("------------------------------------------------------------");
		일시정지();
	}

	private void 일시정지() {
		System.out.print("\t\t> 계속하려면 엔터치세요....");
		try {
			System.in.read();
			System.in.skip(System.in.available());
		} catch (IOException e) { 
			e.printStackTrace();
		}
	}

	private void exit() { 
		DBConn.close();
		System.out.println("\t\t\t 프로그램 종료!!!");
		System.exit(-1);
	}

	private void selectMenu() { 
		System.out.print("> 메뉴 선택하세요 ? ");
		// 유효성 검사 ***
		this.selectedNumber = this.scanner.nextInt();
	}

	private void printMenu() {
		String [] menus = {"새글","목록","보기"
				,"수정","삭제","검색","종료"};
		System.out.println("[ 메뉴 ]");
		for (int i = 0; i < menus.length; i++) {
			System.out.printf("%d. %s\t", i+1, menus[i]);
		}
		System.out.println();
	}

}










